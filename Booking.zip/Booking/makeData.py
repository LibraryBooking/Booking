import os
import re
import cv2 as cv
import pandas as pd
import numpy as np
filelist=os.listdir('Dataset\\image')
path='Dataset\\image\\'


def ImageProcessBig( ArrPic):
    '''
    色彩分割,针对图书馆需要定义红蓝紫三色提取文字,再腐蚀膨胀获取坐标,然后就是随机点击了.
    :param ArrPic:
    :return:
    '''
    # encoding：utf-8
    # 黄色检测
    try:
        Arr = cv.cvtColor(ArrPic, cv.COLOR_BGR2HSV)
        lower2 = np.array([115, 195, 105], dtype="uint8")  # 颜色下限
        upper2 = np.array([180, 255, 195], dtype="uint8")  # 颜色上限
        # 根据阈值找到对应颜色

        mask = cv.inRange(Arr, lowerb=lower2, upperb=upper2)
    except:
        mask=np.ones((40,40))



    return mask


for i,item in enumerate(filelist):
    if 'label' in item:
        num=re.sub(u"([^\u0030-\u0039])","",item)
        label=pd.read_csv(path+item,header=None).astype('int')

        label[2]=label[2]+3#扩大一下范围
        label[4]=label[4]+3
        label[1]=label[1]-3
        label[3]=label[3]-3
        label[label<0]=0
        label[label>330]=330
        beta=label[3]
        beta[beta>160]=160
        label[3]=beta
        imgdict={}
        order=pd.read_csv(path+'order'+num+'.csv',header=None).astype('int')


        img=cv.imread(path+'img'+num+'.png')

        for it in range(4):
            imgdict[str(it)]=img[label[4][it]:label[3][it],label[2][it]:label[1][it],:]
            pass
        img_to1=imgdict[str(order[0][0])]
        img_to2=imgdict[str(order[0][1])]
        del imgdict[str(order[0][0])],imgdict[str(order[0][1])]

        for i,ite in enumerate(imgdict):
            try:
                cv.imwrite(path+'Else'+str(i)+'_'+num+'.png',(imgdict[ite]))
            except:
                pass
        cv.imwrite(path+'sim' + '1_' + num + '.png', (img_to1))
        cv.imwrite(path+'sim' + '2_' + num + '.png', (img_to2))

        img1=cv.imread(path+'1st'+num+'.png',0)
        img2=cv.imread(path+'2nd'+num+'.png',0)

        mean = img1.mean()
        img1[img1 > mean] = 255
        img1[img1 < mean] = 0

        mean = img2.mean()
        img2[img2 > mean] = 255
        img2[img2 < mean] = 0

        cv.imwrite(path + '1st' + num + '.png', img1)
        cv.imwrite(path + '2nd' + num + '.png', img2)
        A=1