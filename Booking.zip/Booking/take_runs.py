from detect import run


A=run(weights='best.pt',source='1.jpg',imgsz=[352,352],save_txt=True,max_det=100,hide_labels=True)

