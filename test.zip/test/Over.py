import time
import http.client
import torch

import torchvision.transforms as transforms
from selenium.webdriver.common.by import By
from torch.utils.data import DataLoader

from detect import run
from CodeDetect.model import getData,getPicCenter,TestSet
from selenium.webdriver.common.action_chains import ActionChains












def get_webservertime(host):
    conn=http.client.HTTPConnection(host)
    conn.request("GET", "/",)
    r=conn.getresponse()
    #r.getheaders() #获取所有的http头
    ts=  r.getheader('date') #获取http头date部分
    #将GMT时间转换成北京时间
    ltime= time.strptime(ts[5:25], "%d %b %Y %H:%M:%S")
    hour=ltime.tm_hour+8
    hour=hour%24
    minute=ltime.tm_min
    second=ltime.tm_sec

    return hour,minute,second


def Login(name,password):
    test_times=0
    T=0
    if torch.cuda.is_available():
        device = torch.device('gpu')
        print(device)
    else:
        device = torch.device('cpu')
        print(device)

    transform = transforms.Compose([transforms.Resize((50, 50)),  # 有坑，传入int和tuple有区别
                                    transforms.ToTensor()])
    test_set=TestSet(transform)

    CodeModel=(torch.load('CodeDetect//textDetect.pt',map_location=device))
    CodeModel.eval()
    while (True):
        browser=getData()
        while True:
            BigArr=browser.getArrPic()
            qian_small,hou_small=browser.ImageProcessSma()
            #qian_small,hou_small=torch.from_numpy(qian_small),torch.from_numpy(hou_small)

            detected_position=run(weights='positionDetect.pt',imgsz=[352,352],max_det=4,img=BigArr)
            detected_position=detected_position[:,(0,1,2,3,5)]
            #image = Image.fromarray(cv.cvtColor(BigArr,cv.COLOR_BGR2RGB))
            #cv.imshow('s',Pic2)
            #cv.waitKey(0)
            hou = detected_position[:, 4].astype('int')
            hou = hou.tolist()
            if 1 not in hou:
                browser.getNew()
                continue

            Pic1,Pic2,Pic3,Center=getPicCenter(BigArr,detected_position)



            test_set.getImageFromNumpy(qian_small,Pic1,Pic2,Pic3)
            test_dataloader = DataLoader(test_set,
                                          shuffle=False,
                                          batch_size=1)
            Pic_Sim = []
            for i,data in enumerate(test_dataloader):
                qian_small, Pic1, Pic2, Pic3=data

                Pic_Sim.append(CodeModel.forward(Pic1,qian_small).item())
                Pic_Sim.append(CodeModel.forward(Pic2,qian_small).item())
                Pic_Sim.append(CodeModel.forward(Pic3,qian_small).item())
                pass
            index=Pic_Sim.index(max(Pic_Sim))
            print('index',index)
            center_qian=Center[index]
            center_hou=Center[3]
            test_times += 1
            browser.OrderClick2((center_qian,center_hou))#验证码结束了
            time.sleep(0.5)
            if '验证失败'   not in browser.driver.page_source:
                print('一共测试',test_times,'次')

                time.sleep(1)
                break
            time.sleep(1.5)


        browser.Login(name=name,password=password)

        T1=time.time()
        try:
            browser.driver.get('https://seat.lib.whu.edu.cn/history?type=SEAT')
            time.sleep(0.05)

            seat = browser.driver.find_element(By.LINK_TEXT, '取消预约')
            seat.click()
            exit(0)
        except:
            print('没有预约')
            pass
        browser.driver.get('https://seat.lib.whu.edu.cn/self')
        seat=browser.driver.find_element(By.XPATH,'//*[@id="search"]/div[1]/dl/dd[4]/input')


        try:
               seat.click()
        except:
            browser.driver.save_screenshot('ffdsfl.png')
            exit(5)
        seat = browser.driver.find_element(By.XPATH, '/html/body/div[6]/dl/dd[2]')
        seat.click()
        seat = browser.driver.find_element(By.XPATH, '/html/body/div[6]/dl/dd[5]')
        seat.click()
        seat = browser.driver.find_element(By.XPATH, '/html/body/div[6]/dl/dd[4]')
        seat.click()
        seat = browser.driver.find_element(By.LINK_TEXT, '确 认')
        seat.click()
        time.sleep(0.1)
        seat = browser.driver.find_element(By.ID, 'seat_55363')
        seat.click()
        hour,minute,second=get_webservertime('reserv.lib.whu.edu.cn')
        T=(60+30-minute+10)*60
        if hour+1<10:hour='0'+str(hour+1)
        else: hour=str(hour+1)
        if hour=='22': break
        times=hour+':'+'30'
        seat = browser.driver.find_element(By.LINK_TEXT, times)
        seat.click()
        time.sleep(0.1)
        seat = browser.driver.find_element(By.LINK_TEXT, '22:30')
        seat.click()
        seat = browser.driver.find_element(By.LINK_TEXT, '预 约')
        seat.click()
        T2=time.time()
        print(T2-T1,T)
        print(hour,minute,second)
       # time.sleep(T)
        browser.driver.close()



        pass


    return browser



print('结束')










