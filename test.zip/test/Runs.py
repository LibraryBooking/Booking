from Over import Login


browser=Login(name='',password='')
'''
后面的自己写
'''
A=1
browser.driver.get('https://seat.lib.whu.edu.cn/freeBook/fav')
