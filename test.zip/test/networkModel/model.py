
import torch.nn as nn
import torch

import torchvision.transforms as transforms
from torch.utils.data import DataLoader,Dataset
import matplotlib.pyplot as plt

import numpy as np
import random
from PIL import Image
'''import PIL.ImageOps
import torchvision
from torch import optim
import torch.nn.functional as F
import torchvision.utils'''

random.seed(42)


def imshow(img,text=None,should_save=False):
    #展示一幅tensor图像，输入是(C,H,W)
    npimg = img.numpy() #将tensor转为ndarray
    plt.axis("off")
    if text:
        plt.text(75, 8, text, style='italic',fontweight='bold',
            bbox={'facecolor':'white', 'alpha':0.8, 'pad':10})
    plt.imshow(np.transpose(npimg, (1, 2, 0))) #转换为(H,W,C)
    plt.show()

def show_plot(iteration,loss):
    #绘制损失变化图
    plt.plot(iteration,loss)
    plt.show()


class SiameseNetworkDatasetTrain(Dataset):

    def __init__(self):

        self.transformBig  = transforms.Compose([transforms.Resize((50, 50)),                      transforms.ToTensor()])
        self.transformSmall  = transforms.Compose([transforms.Resize((20, 19)),                      transforms.ToTensor()])

    def __getitem__(self, index):
        should_1 = random.randint(0, 1)
        # should_1=1
        pathRgb = 'E://yolov5//image//'
        if should_1 == 1:


            img_rgb = Image.open(pathRgb + 'imgT' + str(index + 1) + '.png', )

        else :

            img_rgb = Image.open(pathRgb + 'imgF' + str(index + 1) + '.png', )


        path_val= 'E://yolov5//image1//'
        img_val=Image.open(path_val+'imgV'+str(index+1)+'.png')

        label=torch.from_numpy(np.array([should_1], dtype=np.float32))
        if self.transformBig is not None:
            img_rgb = self.transformBig(img_rgb)
            img_val=self.transformSmall(img_val)



        return img_rgb, img_val, label

    def __len__(self):
        return 6264


class SiameseNetworkDatasetTest(Dataset):

    def __init__(self, ):

        self.transformBig  = transforms.Compose([transforms.Resize((50, 50)),                      transforms.ToTensor()])
        self.transformSmall  = transforms.Compose([transforms.Resize((20, 19)),                      transforms.ToTensor()])


    def __getitem__(self, index):

        # should_1=1
        index+=5500
        pathRgb = 'E://yolov5//image//'
        path_val = 'E://yolov5//image1//'

        img_rgbT = Image.open(pathRgb + 'imgT' + str(index + 1) + '.png', )
        img_rgbF = Image.open(pathRgb + 'imgF' + str(index + 1) + '.png', )

        img_val = Image.open(path_val + 'imgV' + str(index + 1) + '.png')

        if self.transformBig is not None:
            img_rgbF = self.transformBig(img_rgbF)
            img_rgbT = self.transformBig(img_rgbT)
            img_val=self.transformSmall(img_val)


        return img_rgbT,img_rgbF, img_val

    def __len__(self):
        return 764

class SiameseNetworkDatasetVal(Dataset):

    def __init__(self, ):

        self.transform  = transforms.Compose([transforms.Resize((50, 50)),  # 有坑，传入int和tuple有区别
                                transforms.ToTensor()])

    def __getitem__(self, index):

        # should_1=1
        index+=6200
        pathRgb = 'E://yolov5//image//'
        path_val = 'E://yolov5//image1//'

        img_rgbT = Image.open(pathRgb + 'imgT' + str(index + 1) + '.png', )
        img_rgbF = Image.open(pathRgb + 'imgF' + str(index + 1) + '.png', )

        img_val = Image.open(path_val + 'imgV' + str(index + 1) + '.png')

        if self.transform is not None:
            img_rgbF = self.transform(img_rgbF)
            img_rgbT = self.transform(img_rgbT)
            img_val=self.transform(img_val)


        return img_rgbT,img_rgbF, img_val

    def __len__(self):
        return 64


class SiameseNetwork(nn.Module):
    def __init__(self):

        super().__init__()
        self.drop = nn.Dropout(p=0.3)
        self.cnnRGB = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(3, 32, kernel_size=5),
            nn.MaxPool2d((3, 3), stride=1),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(32),

            nn.ReflectionPad2d(1),
            nn.Conv2d(32, 16, kernel_size=5),
            nn.MaxPool2d((3, 3), stride=1),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(16),

            nn.ReflectionPad2d(1),
            nn.Conv2d(16, 4, kernel_size=5),

            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(4),

            nn.ReflectionPad2d(1),
            nn.Conv2d(4, 1, kernel_size=5),
            nn.MaxPool2d((3, 3), stride=1),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(1),


            nn.Flatten(),



            nn.Linear(1296,512),
            nn.Tanh(),



            nn.Linear(512, 400),



        )
        self.cnnGrey = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(1, 8, kernel_size=3),
            nn.MaxPool2d((3, 3), stride=1),
            nn.ReLU(inplace=True),
            nn.BatchNorm2d(8),

            nn.ReflectionPad2d(1),
            nn.Conv2d(8, 16, kernel_size=3),
            nn.MaxPool2d((3, 3), stride=1),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(16),

            nn.ReflectionPad2d(1),
            nn.Conv2d(16, 2, kernel_size=3),

            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(2),

            nn.Flatten(),

            nn.Linear(480,512),
            nn.Tanh(),



            nn.Linear(512,400),





        )
        self.Linear = nn.Sequential(


            nn.Linear(400, 512),
            nn.LeakyReLU(inplace=True),

            nn.Linear(512, 256,),
            nn.LeakyReLU(inplace=True),

            nn.Linear(256,128),
            nn.LeakyReLU(inplace=True),

            nn.Linear(128, 64),
            nn.LeakyReLU(inplace=True),

            nn.Linear(64, 1),

            nn.Sigmoid()
        )

    def forward_rgb(self, x):
        output = self.cnnRGB(x)
        output = output.view(output.size()[0], -1)

        return output
    def forward_grey(self, x):
        output = self.cnnGrey(x)
        output = output.view(output.size()[0], -1)

        return output

    def forward(self, input1, input2):
        output1 = self.forward_rgb(input1)
        output2 = self.forward_grey(input2)
        output1=self.drop(output1)
        output2=self.drop(output2)
        #   print(output1.size())

        #   print(outputR0.size())

        #     print(out.size())
        outputR = self.Linear(torch.abs(output1 - output2))
        return outputR


class ContrastiveLoss(torch.nn.Module):
    """
    Contrastive loss function.
    Based on: http://yann.lecun.com/exdb/publis/pdf/hadsell-chopra-lecun-06.pdf
    """

    def __init__(self, margin=2.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin
        self.m = torch.nn.BCELoss()

    def forward(self, output, label):
        #    print(euclidean_distance)
        #    print(label)
        loss_contrastive = self.m(output, label.float())
        #  print(loss_contrastive)

        return loss_contrastive

def conmat(TP,TN,FP,FN):
    F1=2*TP/(2*TP+FP+FN)

